# Al-Qur'an Digital

Aplikasi Android native Java untuk membaca Al-Qur'an, mendengarkan murottal, dan membantu latihan hafalan. Package: `com.fr.media.alqurandigital`.

## Fitur yang diimplementasikan
- Data teks 114 surah dan 6.236 ayat disimpan di aset lokal, termasuk terjemahan Indonesia, metadata juz, dan tafsir Kemenag yang ada pada sumber.
- Daftar surah dengan pencarian nama, nomor, dan terjemahan nama.
- Membaca ayat, surah, dan juz.
- Audio per ayat menggunakan URL audio yang disediakan data sumber.
- Pilihan enam qari yang tersedia pada data.
- Kecepatan audio 1,0x, 1,25x, dan 1,5x.
- Pengulangan ayat dengan pengaturan awal aktif, tiga kali, dan pilihan tanpa batas.
- Pilih rentang ayat untuk latihan.
- Favorit, status hafalan, posisi bacaan terakhir, dan preferensi tersimpan lokal.
- Pencarian terjemahan, ukuran teks, tafsir, kontrol audio, dan navigasi native.
- Antarmuka Android native Java, bukan WebView.

## Versi 1.0.1: perbaikan kompilasi
- Memperbaiki listener dua parameter pada kedua sakelar pengaturan pengulangan agar sesuai dengan `CompoundButton.OnCheckedChangeListener`.
- Menaikkan `versionCode` menjadi 2 dan `versionName` menjadi `1.0.1`.
- Data diverifikasi secara lokal: 114 surah dan 6.236 ayat.

## Build melalui GitHub Actions
1. Unggah isi folder proyek ini ke repositori GitHub.
2. Buka tab Actions.
3. Pilih `Build Al-Quran Digital APK`.
4. Tekan `Run workflow` atau push ke branch `main`.
5. Unduh artifact `AlQuranDigital-debug-apk` untuk pengujian.

Workflow membutuhkan JDK 17 dan Android SDK 35. APK hasil build Actions adalah APK debug untuk pengujian, bukan rilis yang sudah ditandatangani untuk distribusi publik.

## Data dan lisensi
Data bersumber dari proyek Quran API Indonesia yang dilampirkan bersama tugas. Lihat `NOTICE-QURAN-DATA-LICENSE.txt` dan `NOTICE-QURAN-API-README.md` untuk atribusi dan lisensi sumber. Periksa juga ketentuan lisensi dan atribusi dari penyedia audio sebelum mendistribusikan aplikasi.

## Status kesiapan rilis
Versi ini adalah kandidat untuk pengujian rilis, bukan klaim bahwa aplikasi sudah siap dipublikasikan tanpa pengujian. Kompilasi Android belum dapat dijalankan secara lokal pada lingkungan pembuatan ZIP. GitHub Actions harus berhasil sebelum APK dianggap berhasil dibangun.

## Batasan yang perlu diuji
- Audio membutuhkan koneksi internet. Teks lokal tetap dapat dibaca tanpa koneksi.
- Proyek ini belum diuji di perangkat Android fisik dalam lingkungan pembuatan ZIP.
- Periksa perilaku pengulangan audio pada perangkat nyata, terutama transisi otomatis antar-ayat dan ketika audio berakhir.
- Belum ada fitur unduh audio untuk pemakaian offline.
- Belum ada ekspor/impor cadangan data pengguna.
- Sebelum rilis publik, lakukan uji aksesibilitas TalkBack dan validasi teks mushaf terhadap rujukan tepercaya.


## Perubahan v1.0.2
- Menambahkan sakelar "Lanjut otomatis ke surah berikutnya". Default nonaktif dan dapat diubah dari Pengaturan. Fitur berlaku saat memutar satu surah penuh, bukan saat memutar satu ayat, rentang hafalan, atau juz.
- Menambahkan foreground service tipe pemutaran media dan mode wake lock ExoPlayer agar pemutaran lebih mampu bertahan ketika layar mati atau aplikasi berada di latar belakang. Perilaku tetap perlu diuji pada perangkat, karena beberapa merek Android memiliki penghemat baterai yang dapat menghentikan proses.
- Audio pada sumber data yang tersedia menggunakan MP3 128 kbps. Aplikasi tidak dapat memulihkan detail suara yang memang tidak ada pada file sumber. Kejernihan juga dipengaruhi jaringan, speaker, headphone, dan pengaturan volume perangkat.
- Basmalah ditampilkan terpisah di awal surah kecuali Al-Fatihah dan At-Taubah. Basmalah Al-Fatihah tetap bagian dari ayat pertama, sedangkan Basmalah pada An-Naml ayat 30 tetap berada di teks ayatnya.


## Audio Bismillah

Pemutaran seluruh surah menyisipkan audio Bismillah sebelum ayat pertama pada setiap surah, kecuali Al-Fatihah (surah 1, karena Bismillah sudah menjadi ayat pertama) dan At-Taubah (surah 9). Audio pembuka menggunakan rekaman ayat pertama Al-Fatihah dari qari yang dipilih agar suara Bismillah mengikuti pilihan qari. Saat pemutaran otomatis berpindah ke surah berikutnya, aturan yang sama diterapkan. Audio Bismillah tidak dihitung sebagai ayat dan tidak ikut pengulangan ayat.
