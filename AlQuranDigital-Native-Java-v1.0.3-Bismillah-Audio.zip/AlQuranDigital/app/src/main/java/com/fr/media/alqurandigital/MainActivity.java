package com.fr.media.alqurandigital;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@UnstableApi
public class MainActivity extends AppCompatActivity {
    private final int GREEN=Color.rgb(6,78,59), GREEN2=Color.rgb(8,127,91), BG=Color.rgb(246,248,247), TEXT=Color.rgb(25,35,31), MUTED=Color.rgb(90,105,98), WHITE=Color.WHITE;
    private LinearLayout root, body, topBar, bottomBar;
    private ScrollView mainScroll;
    private TextView titleView, statusView;
    private JSONArray surahs;
    private final ArrayList<JSONObject> allAyahs=new ArrayList<>();
    private final ArrayList<JSONObject> queue=new ArrayList<>();
    private ExoPlayer player;
    private SharedPreferences prefs;
    private String screen="home", returnScreen="home", selectedMode="surah", selectedQari="alafasy";
    private int selectedSurah=1, selectedJuz=1, currentAyahGlobal=1, repeatCount=3, repeatsDone=0, repeatStartIndex=0, repeatEndIndex=-1;
    private boolean repeatEnabled=true, repeatForever=false, repeatRange=false, queueMode=false, autoNextSurah=false, autoNextSurahMode=false;
    private float arabicSize=27f, translationSize=16f;
    private String lastScreen="surah", searchQuery="";
    private final String[] qariKeys={"alafasy","ahmedajamy","husarymujawwad","minshawi","muhammadayyoub","muhammadjibreel"};
    private final String[] qariNames={"Mishari Alafasy","Ahmed ibn Ali al-Ajamy","Husary Mujawwad","Minshawi","Muhammad Ayyoub","Muhammad Jibreel"};

    @Override public void onCreate(Bundle state){super.onCreate(state); getWindow().setStatusBarColor(GREEN); getWindow().setNavigationBarColor(GREEN); prefs=getSharedPreferences("quran_local",MODE_PRIVATE); loadPrefs(); buildBase(); loadQuran(); showHome();}
    private void loadPrefs(){selectedQari=prefs.getString("qari","alafasy"); repeatEnabled=prefs.getBoolean("repeat",true); repeatCount=prefs.getInt("repeatCount",3); repeatForever=prefs.getBoolean("repeatForever",false); autoNextSurah=prefs.getBoolean("autoNextSurah",false); arabicSize=prefs.getFloat("arabicSize",27f); translationSize=prefs.getFloat("translationSize",16f); selectedSurah=prefs.getInt("lastSurah",1); currentAyahGlobal=prefs.getInt("lastAyah",1); selectedJuz=prefs.getInt("lastJuz",1);}
    private void buildBase(){root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); setContentView(root); topBar=new LinearLayout(this); topBar.setOrientation(LinearLayout.VERTICAL); topBar.setPadding(dp(18),dp(15),dp(18),dp(14)); topBar.setBackgroundColor(GREEN); root.addView(topBar,new LinearLayout.LayoutParams(-1,-2)); titleView=new TextView(this); titleView.setTextColor(WHITE); titleView.setTextSize(22); titleView.setTypeface(null,Typeface.BOLD); titleView.setContentDescription("Judul halaman"); topBar.addView(titleView); statusView=new TextView(this); statusView.setTextColor(Color.rgb(216,244,229)); statusView.setTextSize(13); statusView.setText("Baca, Dengarkan, dan Hafalkan Al-Qur'an"); topBar.addView(statusView); ScrollView scroll=new ScrollView(this); mainScroll=scroll; scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(16),dp(14),dp(16),dp(24)); scroll.addView(body); bottomBar=new LinearLayout(this); bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setPadding(dp(6),dp(6),dp(6),dp(6)); bottomBar.setBackgroundColor(WHITE); root.addView(bottomBar,new LinearLayout.LayoutParams(-1,-2)); addBottom("Beranda","home"); addBottom("Surah","surahs"); addBottom("Juz","juz"); addBottom("Hafalan","hafalan"); addBottom("Pengaturan","settings"); }
    private void loadQuran(){try(InputStream in=getAssets().open("quran.json"); ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[32768]; int n; while((n=in.read(b))!=-1)out.write(b,0,n); surahs=new JSONArray(out.toString("UTF-8")); for(int i=0;i<surahs.length();i++){JSONObject s=surahs.getJSONObject(i); JSONArray a=s.getJSONArray("ayahs"); for(int j=0;j<a.length();j++){JSONObject x=a.getJSONObject(j); x.put("_surah",s.getInt("number")); x.put("_surahName",s.getString("name")); allAyahs.add(x);}} statusView.setText("114 surah · "+allAyahs.size()+" ayat tersedia offline");}catch(Exception e){showError("Data Al-Qur'an tidak dapat dibuka: "+e.getMessage());}}
    private void page(String name,String sub){screen=name; titleView.setText(sub); body.removeAllViews();}
    private void showHome(){page("home","Al-Qur'an Digital"); addCardTitle("Assalamu'alaikum"); addText("Teman membaca, mendengarkan, dan menghafal Al-Qur'an.",16,MUTED); addButton("Lanjutkan Bacaan",()->openLast()); addButton("Daftar 114 Surah",()->showSurahs("")); addButton("Pilih Juz 1 sampai 30",()->showJuz()); addButton("Latihan Hafalan",()->showHafalan()); addButton("Ayat Favorit",()->showFavorites()); addButton("Cari Ayat",()->showSearch()); addButton("Pengaturan Bacaan",()->showSettings()); addSpace(10); addText("Teks Arab dan terjemahan tersedia secara offline. Audio murottal memerlukan internet.",14,MUTED); addText("FR Media Digital · Fathurozi",13,MUTED); }
    private JSONObject getSurah(int n){try{return surahs.getJSONObject(n-1);}catch(Exception e){return null;}}
    private JSONObject getAyah(int surah,int ayah){try{return getSurah(surah).getJSONArray("ayahs").getJSONObject(ayah-1);}catch(Exception e){return null;}}
    private void openLast(){JSONObject a=null; for(JSONObject x:allAyahs)if(x.optJSONObject("number")!=null&&x.optJSONObject("number").optInt("inQuran",0)==currentAyahGlobal){a=x;break;} if(a==null){selectedSurah=1;openSurah(1);return;} selectedSurah=intVal(a,"_surah",1); openSurah(selectedSurah); scrollToAyah(currentAyahGlobal);}
    private void showSurahs(String filter){page("surahs","Daftar Surah"); EditText search=new EditText(this); search.setSingleLine(true); search.setHint("Cari nama atau nomor surah"); search.setText(filter); search.setContentDescription("Cari nama atau nomor surah"); body.addView(search,matchWrap()); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list); Runnable render=()->{list.removeAllViews();String f=search.getText().toString().toLowerCase(Locale.ROOT).trim();for(int i=0;i<surahs.length();i++){JSONObject s=surahs.optJSONObject(i);String nm=s.optString("name");if(!f.isEmpty()&&!String.valueOf(i+1).contains(f)&&!nm.toLowerCase(Locale.ROOT).contains(f)&&!s.optString("translation").toLowerCase(Locale.ROOT).contains(f))continue; final int no=i+1; addListItem(list,no+". "+nm+" · "+s.optString("translation"),s.optInt("numberOfAyahs")+" ayat · "+s.optString("revelation"),()->openSurah(no));}};render.run();search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render.run();}public void afterTextChanged(Editable e){}}); }
    private void openSurah(int n){selectedSurah=n; prefs.edit().putInt("lastSurah",n).apply(); JSONObject s=getSurah(n); if(s==null)return; page("surah",s.optString("name")+" · "+s.optString("translation")); addText("Surah "+n+" · "+s.optInt("numberOfAyahs")+" ayat · "+s.optString("revelation"),14,MUTED); LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);body.addView(controls);addButtonTo(controls,"Putar seluruh surah",()->playSurah(n,0,s.optInt("numberOfAyahs")-1)); addButtonTo(controls,"Pilih rentang ayat untuk hafalan",()->rangeDialog(n)); addButtonTo(controls,"Lihat tafsir surah/ayat",()->{JSONObject a=getAyah(n,1);if(a!=null)showTafsir(a);}); JSONArray aa=s.optJSONArray("ayahs"); if(n!=1&&n!=9){JSONObject b=s.optJSONObject("bismillah"); if(b!=null){addText("بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ",arabicSize, TEXT, true);addText("Dengan nama Allah Yang Maha Pengasih, Maha Penyayang.",translationSize,MUTED);}} if(aa!=null)for(int i=0;i<aa.length();i++){JSONObject a=aa.optJSONObject(i);if(a!=null)addAyahCard(a);}}
    private void addAyahCard(JSONObject a){int no=ayahNo(a);int sn=intVal(a,"_surah",selectedSurah); LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(round(WHITE,14,Color.rgb(225,233,228)));LinearLayout.LayoutParams cp=matchWrap();cp.bottomMargin=dp(10);body.addView(card,cp);card.setTag(a.optJSONObject("number")!=null?a.optJSONObject("number").optInt("inQuran",0):0);int juz=a.optJSONObject("meta")!=null?a.optJSONObject("meta").optInt("juz",1):1;TextView heading=new TextView(this);heading.setText("Ayat "+no+" · Juz "+juz);heading.setTextColor(GREEN2);heading.setTextSize(14);heading.setTypeface(null,Typeface.BOLD);card.addView(heading);TextView arab=new TextView(this);arab.setText(a.optString("arab"));arab.setTextColor(TEXT);arab.setTextSize(arabicSize);arab.setGravity(Gravity.RIGHT);arab.setTextDirection(View.TEXT_DIRECTION_RTL);arab.setLineSpacing(dp(8),1f);arab.setContentDescription("Teks Arab, "+sn+", ayat "+no+": "+a.optString("arab"));LinearLayout.LayoutParams ap=matchWrap();ap.topMargin=dp(10);ap.bottomMargin=dp(10);card.addView(arab,ap);TextView trans=new TextView(this);trans.setText(a.optString("translation"));trans.setTextColor(MUTED);trans.setTextSize(translationSize);card.addView(trans);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);card.addView(row);smallButton(row,"Putar",()->playSingle(a));smallButton(row,isFavorite(a)?"Hapus Favorit":"Favorit",()->toggleFavorite(a));smallButton(row,"Hafalan",()->chooseHafalan(a));smallButton(row,"Tafsir",()->showTafsir(a));}
    private void showJuz(){page("juz","Pilih Juz");addText("Pilih salah satu dari 30 juz. Daftar akan dimulai dari ayat awal juz dan mengikuti batas juz yang benar.",15,MUTED);for(int j=1;j<=30;j++){final int juz=j;addListItem(body,"Juz "+j,"Buka ayat dalam juz "+j,()->openJuz(juz));}}
    private void openJuz(int j){selectedJuz=j;prefs.edit().putInt("lastJuz",j).apply();page("juzcontent","Juz "+j);addText("Ayat yang termasuk Juz "+j,14,MUTED);ArrayList<JSONObject> selected=new ArrayList<>();for(JSONObject a:allAyahs){JSONObject m=a.optJSONObject("meta");if(m!=null&&m.optInt("juz",-1)==j)selected.add(a);}if(!selected.isEmpty()){addButton("Putar seluruh Juz "+j,()->playQueue(selected,0,selected.size()-1));JSONObject first=selected.get(0),last=selected.get(selected.size()-1);addText("Mulai: "+first.optString("_surahName")+" ayat "+ayahNo(first)+". Akhir: "+last.optString("_surahName")+" ayat "+ayahNo(last)+".",14,MUTED);}for(JSONObject a:selected)addAyahCard(a);}
    private void showSettings(){page("settings","Pengaturan");addCardTitle("Pengaturan bacaan");addSwitch("Lanjut otomatis ke surah berikutnya",autoNextSurah,(button, checked)->{autoNextSurah=checked;prefs.edit().putBoolean("autoNextSurah",checked).apply();});addText("Jika aktif, pemutar akan melanjutkan ke surah berikutnya setelah satu surah selesai. Tidak berlaku untuk pemutaran rentang ayat atau juz.",14,MUTED);addSwitch("Ulangi ayat (default 3 kali)",repeatEnabled,(button, checked)->{repeatEnabled=checked;prefs.edit().putBoolean("repeat",checked).apply();});addSwitch("Ulangi terus sampai dihentikan",repeatForever,(button, checked)->{repeatForever=checked;prefs.edit().putBoolean("repeatForever",checked).apply();});addButton("Jumlah pengulangan: "+(repeatForever?"Tanpa batas":repeatCount+" kali"),()->new AlertDialog.Builder(this).setTitle("Jumlah pengulangan").setSingleChoiceItems(new String[]{"1 kali","3 kali","5 kali","10 kali","Tanpa batas"},repeatForever?4:repeatCount==1?0:repeatCount==5?2:repeatCount==10?3:1,(d,w)->{repeatForever=w==4;if(w<4)repeatCount=new int[]{1,3,5,10}[w];prefs.edit().putBoolean("repeatForever",repeatForever).putInt("repeatCount",repeatCount).apply();d.dismiss();showSettings();}).setNegativeButton("Batal",null).show());addButton("Kecepatan: "+speedLabel(),()->new AlertDialog.Builder(this).setTitle("Kecepatan murottal").setSingleChoiceItems(new String[]{"Normal · 1,0x","Lebih cepat · 1,25x","Lebih cepat lagi · 1,5x"},Math.round((speed()-1f)/0.25f),(d,w)->{prefs.edit().putFloat("speed",new float[]{1f,1.25f,1.5f}[w]).apply();if(player!=null)player.setPlaybackSpeed(speed());d.dismiss();showSettings();}).setNegativeButton("Batal",null).show());addButton("Pilih qari: "+qariName(),()->new AlertDialog.Builder(this).setTitle("Pilih qari").setSingleChoiceItems(qariNames,indexQari(),(d,w)->{selectedQari=qariKeys[w];prefs.edit().putString("qari",selectedQari).apply();d.dismiss();showSettings();}).setNegativeButton("Batal",null).show());addButton("Ukuran teks Arab",()->new AlertDialog.Builder(this).setTitle("Ukuran teks Arab").setSingleChoiceItems(new String[]{"Kecil","Sedang","Besar","Sangat besar"},arabicSize==22?0:arabicSize==27?1:arabicSize==32?2:3,(d,w)->{arabicSize=new float[]{22,27,32,37}[w];prefs.edit().putFloat("arabicSize",arabicSize).apply();d.dismiss();showSettings();}).setNegativeButton("Batal",null).show());addButton("Ukuran terjemahan",()->new AlertDialog.Builder(this).setTitle("Ukuran terjemahan").setSingleChoiceItems(new String[]{"Kecil","Sedang","Besar"},translationSize==14?0:translationSize==16?1:2,(d,w)->{translationSize=new float[]{14,16,20}[w];prefs.edit().putFloat("translationSize",translationSize).apply();d.dismiss();showSettings();}).setNegativeButton("Batal",null).show());addButton("Tentang aplikasi",()->showAbout());}
    private void showHafalan(){page("hafalan","Hafalan Saya");addText("Tandai perkembangan hafalan ayat. Semua status tersimpan di perangkat ini.",15,MUTED);addButton("Lihat semua ayat yang sedang dihafal",()->showHafalanStatus("sedang"));addButton("Lihat ayat yang sudah hafal",()->showHafalanStatus("hafal"));addButton("Ayat yang perlu diulang",()->showHafalanStatus("ulang"));addButton("Pilih surah untuk mulai menghafal",()->showSurahs(""));}
    private void showHafalanStatus(String status){page("hafalanstatus","Status Hafalan");addText("Status: "+status,14,MUTED);int count=0;for(JSONObject a:allAyahs){if(status.equals(prefs.getString(hkey(a),"belum"))){addListItem(body,a.optString("_surahName")+" ayat "+ayahNo(a),a.optString("translation"),()->{selectedSurah=intVal(a,"_surah",1);openSurah(selectedSurah);JSONObject nn=a.optJSONObject("number");if(nn!=null)scrollToAyah(nn.optInt("inQuran",0));});count++;}}if(count==0)addText("Belum ada ayat dengan status ini.",15,MUTED);}
    private void chooseHafalan(JSONObject a){String[] vals={"Belum mulai","Sedang dihafal","Sudah hafal","Perlu diulang"};String[] keys={"belum","sedang","hafal","ulang"};String current=prefs.getString(hkey(a),"belum");int checked=0;for(int i=0;i<keys.length;i++)if(keys[i].equals(current))checked=i;new AlertDialog.Builder(this).setTitle("Status hafalan").setSingleChoiceItems(vals,checked,(d,w)->{prefs.edit().putString(hkey(a),keys[w]).apply();d.dismiss();Toast.makeText(this,"Status hafalan disimpan",Toast.LENGTH_SHORT).show();}).setNegativeButton("Batal",null).show();}
    private void showFavorites(){page("favorites","Ayat Favorit");int count=0;for(JSONObject a:allAyahs)if(isFavorite(a)){addListItem(body,a.optString("_surahName")+" ayat "+ayahNo(a),a.optString("translation"),()->{selectedSurah=intVal(a,"_surah",1);openSurah(selectedSurah);JSONObject nn=a.optJSONObject("number");if(nn!=null)scrollToAyah(nn.optInt("inQuran",0));});count++;}if(count==0)addText("Belum ada ayat favorit. Buka sebuah surah lalu tekan tombol Favorit pada ayat yang ingin disimpan.",15,MUTED);}
    private void showSearch(){page("search","Cari Ayat");EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Kata terjemahan, nama atau nomor surah");input.setContentDescription("Kata terjemahan, nama atau nomor surah");body.addView(input,matchWrap());Button go=makeButton("Cari");body.addView(go);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);body.addView(results);Runnable search=()->{results.removeAllViews();String q=input.getText().toString().trim().toLowerCase(Locale.ROOT);if(q.length()<2)return;int c=0;for(JSONObject a:allAyahs){String trans=a.optString("translation").toLowerCase(Locale.ROOT), sn=a.optString("_surahName").toLowerCase(Locale.ROOT);if(trans.contains(q)||sn.contains(q)||String.valueOf(a.optInt("_surah")).equals(q)||String.valueOf(ayahNo(a)).equals(q)){addListItem(results,a.optString("_surahName")+" ayat "+ayahNo(a),a.optString("translation"),()->{selectedSurah=intVal(a,"_surah",1);openSurah(selectedSurah);});if(++c>=100)break;}}if(c==0)addTextTo(results,"Tidak ditemukan hasil yang cocok.",14,MUTED);};go.setOnClickListener(v->search.run());input.setOnEditorActionListener((v,id,event)->{search.run();return true;});}
    private void showTafsir(JSONObject a){JSONObject t=a.optJSONObject("tafsir");if(t==null){new AlertDialog.Builder(this).setTitle("Tafsir tidak tersedia").setMessage("Data tafsir untuk ayat ini tidak tersedia dalam berkas lokal.").setPositiveButton("Tutup",null).show();return;}JSONObject k=t.optJSONObject("kemenag");if(k==null){new AlertDialog.Builder(this).setTitle("Tafsir").setMessage("Tafsir belum tersedia.").setPositiveButton("Tutup",null).show();return;}String shortText=k.optString("short","Tidak tersedia");String longText=k.optString("long","");new AlertDialog.Builder(this).setTitle("Tafsir "+a.optString("_surahName")+" ayat "+ayahNo(a)).setMessage(shortText+(longText.isEmpty()?"":"\n\nTafsir lengkap:\n"+longText)).setPositiveButton("Tutup",null).show();}
    private void showAbout(){page("about","Tentang Aplikasi");addCardTitle("Al-Qur'an Digital");addText("Baca, Dengarkan, dan Hafalkan Al-Qur'an",17,GREEN2);addText("Dikembangkan oleh Fathurozi · FR Media Digital",15,TEXT);addText("Mewujudkan Ide Digital Menjadi Solusi Nyata",14,MUTED);addText("Teks dan metadata Al-Qur'an berasal dari proyek Quran API Indonesia yang dilampirkan. Lisensi sumber data MIT, lihat file NOTICE-QURAN-DATA-LICENSE.txt. Audio murottal memerlukan koneksi internet.",14,MUTED);}
    private void playSingle(JSONObject a){autoNextSurahMode=false;ArrayList<JSONObject> one=new ArrayList<>();one.add(a);playQueue(one,0,0);}
    private void playSurah(int n,int start,int end){JSONObject s=getSurah(n);if(s==null)return;autoNextSurahMode=(start==0&&end==s.optInt("numberOfAyahs",0)-1);ArrayList<JSONObject> q=new ArrayList<>();JSONArray aa=s.optJSONArray("ayahs");for(int i=Math.max(0,start);aa!=null&&i<=end&&i<aa.length();i++)q.add(aa.optJSONObject(i));playQueue(q,0,q.size()-1);}
    private void playQueue(ArrayList<JSONObject> src,int start,int end){
        if(src==null||src.isEmpty()){toast("Tidak ada ayat untuk diputar.");return;}
        if(!isOnline())toast("Audio memerlukan koneksi internet. Teks Al-Qur'an tetap dapat dibaca offline.");

        queue.clear();
        int safeStart=Math.max(0,Math.min(start,src.size()-1));
        int safeEnd=Math.min(src.size()-1,end);
        int mappedStart=-1,mappedEnd=-1;
        ArrayList<MediaItem> items=new ArrayList<>();
        for(int i=0;i<src.size();i++){
            JSONObject a=src.get(i);
            if(a==null)continue;
            if(ayahNo(a)==1){
                JSONObject bismillah=createBismillahEntry(intVal(a,"_surah",selectedSurah));
                if(bismillah!=null){
                    queue.add(bismillah);
                    items.add(MediaItem.fromUri(audioUrl(bismillah)));
                }
            }
            if(i==safeStart)mappedStart=queue.size();
            if(i==safeEnd)mappedEnd=queue.size();
            queue.add(a);
            items.add(MediaItem.fromUri(resolveAudioUrl(a)));
        }
        repeatStartIndex=mappedStart<0?0:mappedStart;
        repeatEndIndex=mappedEnd<0?queue.size()-1:mappedEnd;
        if(repeatEndIndex<repeatStartIndex){toast("Rentang ayat tidak valid.");return;}
        try{
            if(player!=null){player.release();player=null;}
            player=new ExoPlayer.Builder(this).build();player.setMediaItems(items);player.seekTo(0,0);player.setPlaybackSpeed(speed());repeatsDone=0;queueMode=true;
            final int[] lastIndex={-1}; final boolean[] seekingForRepeat={false};
            player.addListener(new Player.Listener(){
                @Override public void onMediaItemTransition(MediaItem item,int reason){
                    if(player==null)return;int idx=player.getCurrentMediaItemIndex();if(idx<0||idx>=queue.size())return;
                    if(reason==Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && autoNextSurah && autoNextSurahMode && idx==queue.size()-1){
                        int finishedSurah=intVal(queue.get(idx),"_surah",selectedSurah);
                        if(finishedSurah<114){
                            int nextNumber=finishedSurah+1;
                            JSONObject next=getSurah(nextNumber);
                            JSONArray nextAyahs=next==null?null:next.optJSONArray("ayahs");
                            ArrayList<MediaItem> more=new ArrayList<>();
                            ArrayList<JSONObject> added=new ArrayList<>();
                            JSONObject bismillah=createBismillahEntry(nextNumber);
                            if(bismillah!=null){added.add(bismillah);more.add(MediaItem.fromUri(resolveAudioUrl(bismillah)));}
                            for(int k=0;nextAyahs!=null&&k<nextAyahs.length();k++){
                                JSONObject na=nextAyahs.optJSONObject(k);
                                if(na!=null){more.add(MediaItem.fromUri(resolveAudioUrl(na)));added.add(na);}
                            }
                            if(!more.isEmpty()){queue.addAll(added);repeatEndIndex=queue.size()-1;player.addMediaItems(more);}
                        }
                    }
                    if(reason==Player.MEDIA_ITEM_TRANSITION_REASON_AUTO&&lastIndex[0]>=repeatStartIndex&&lastIndex[0]<=repeatEndIndex&&repeatEnabled&&!seekingForRepeat[0]&&!isBismillahAudio(queue.get(lastIndex[0]))){
                        int old=lastIndex[0];
                        if(repeatForever||repeatsDone<Math.max(0,repeatCount-1)){repeatsDone++;seekingForRepeat[0]=true;lastIndex[0]=old;player.seekTo(old,0);return;}
                        repeatsDone=0;
                    }
                    lastIndex[0]=idx;seekingForRepeat[0]=false;
                    JSONObject a=queue.get(idx);
                    selectedSurah=intVal(a,"_surah",selectedSurah);
                    if(isBismillahAudio(a)){
                        statusView.setText("Memutar Bismillah sebelum Surah "+a.optString("_surahName")+" · "+qariName());
                        return;
                    }
                    JSONObject num=a.optJSONObject("number");currentAyahGlobal=num==null?1:num.optInt("inQuran",1);
                    prefs.edit().putInt("lastSurah",selectedSurah).putInt("lastAyah",currentAyahGlobal).apply();
                    statusView.setText("Memutar "+a.optString("_surahName")+" ayat "+ayahNo(a)+" · "+qariName());
                }
                @Override public void onPlaybackStateChanged(int state){
                    if(player==null||state!=Player.STATE_ENDED)return;
                    int idx=player.getCurrentMediaItemIndex();
                    if(repeatEnabled&&idx>=repeatStartIndex&&idx<=repeatEndIndex&&!isBismillahAudio(queue.get(idx))&&(repeatForever||repeatsDone<Math.max(0,repeatCount-1))){repeatsDone++;player.seekTo(idx,0);player.prepare();player.play();return;}
                    stopService(new Intent(MainActivity.this,AudioKeepAliveService.class));
                }
                @Override public void onPlayerError(PlaybackException error){toast("Audio gagal diputar. Periksa internet atau coba qari lain.");}
            });
            player.setWakeMode(androidx.media3.common.C.WAKE_MODE_LOCAL);Intent keepAlive=new Intent(this,AudioKeepAliveService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(keepAlive);else startService(keepAlive);player.prepare();player.play();showPlayerControls();
        }catch(Exception e){toast("Pemutar audio tidak dapat dijalankan: "+e.getMessage());}
    }
    private JSONObject createBismillahEntry(int surahNumber){
        if(surahNumber==1||surahNumber==9)return null;
        JSONObject firstAyah=getAyah(1,1);
        String url=audioUrl(firstAyah);
        if(url==null||url.isEmpty())url="https://cdn.islamic.network/quran/audio/128/ar.alafasy/1.mp3";
        JSONObject entry=new JSONObject();
        try{
            entry.put("_isBismillahAudio",true);
            entry.put("_surah",surahNumber);
            JSONObject surah=getSurah(surahNumber);
            entry.put("_surahName",surah==null?("Surah "+surahNumber):surah.optString("name","Surah "+surahNumber));
            entry.put("arab","بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ");
            entry.put("translation","Dengan nama Allah Yang Maha Pengasih, Maha Penyayang.");
            JSONObject audio=new JSONObject();
            audio.put(selectedQari,url);
            entry.put("audio",audio);
        }catch(JSONException ignored){}
        return entry;
    }
    private boolean isBismillahAudio(JSONObject a){return a!=null&&a.optBoolean("_isBismillahAudio",false);}
    private String resolveAudioUrl(JSONObject a){
        String url=audioUrl(a);
        if(url==null||url.isEmpty()){
            JSONObject num=a==null?null:a.optJSONObject("number");
            int global=num==null?1:num.optInt("inQuran",1);
            url="https://cdn.islamic.network/quran/audio/128/ar.alafasy/"+global+".mp3";
        }
        return url;
    }
    private void showPlayerControls(){page("player","Pemutar Murottal");addText("Qari: "+qariName()+" · Kecepatan "+speedLabel(),15,MUTED);addText("Pengulangan ayat: "+(repeatEnabled?(repeatForever?"tanpa batas":repeatCount+" kali"):"nonaktif"),15,MUTED);addButton("Jeda / Lanjutkan",()->{if(player==null)return;if(player.isPlaying())player.pause();else player.play();});addButton("Berhenti",()->{if(player!=null){player.stop();player.release();player=null;}stopService(new Intent(this,AudioKeepAliveService.class));statusView.setText("Pemutaran dihentikan");toast("Audio dihentikan");});addButton("Ayat Sebelumnya",()->{if(player!=null&&player.hasPreviousMediaItem())player.seekToPreviousMediaItem();});addButton("Ayat Berikutnya",()->{if(player!=null&&player.hasNextMediaItem())player.seekToNextMediaItem();});addButton("Atur pengulangan dan kecepatan",()->showSettings());addButton("Kembali ke bacaan",()->openSurah(selectedSurah));}
    private void rangeDialog(int surah){JSONObject s=getSurah(surah);int max=s==null?1:s.optInt("numberOfAyahs",1);LinearLayout l=new LinearLayout(this);l.setPadding(dp(16),dp(8),dp(16),0);l.setOrientation(LinearLayout.VERTICAL);EditText from=new EditText(this);from.setInputType(2);from.setHint("Ayat awal (1 sampai "+max+")");from.setText("1");l.addView(from);EditText to=new EditText(this);to.setInputType(2);to.setHint("Ayat akhir (maksimal "+max+")");to.setText(String.valueOf(Math.min(max,5)));l.addView(to);new AlertDialog.Builder(this).setTitle("Pilih rentang ayat").setView(l).setPositiveButton("Mulai latihan",(d,w)->{try{int a=Integer.parseInt(from.getText().toString()),b=Integer.parseInt(to.getText().toString());if(a<1||b<a||b>max){toast("Rentang ayat tidak valid.");return;}playSurah(surah,a-1,b-1);}catch(Exception e){toast("Masukkan nomor ayat yang benar.");}}).setNegativeButton("Batal",null).show();}
    private void scrollToAyah(int global){if(mainScroll==null)return;mainScroll.post(()->{View target=findAyahView(body,global);if(target!=null)mainScroll.smoothScrollTo(0,target.getTop());else toast("Ayat tersimpan: nomor "+global+" dalam Al-Qur'an.");});}
    private View findAyahView(LinearLayout parent,int global){for(int i=0;i<parent.getChildCount();i++){View v=parent.getChildAt(i);Object tag=v.getTag();if(tag instanceof Integer&&((Integer)tag)==global)return v;if(v instanceof LinearLayout){View found=findAyahView((LinearLayout)v,global);if(found!=null)return found;}}return null;}
    private String audioUrl(JSONObject a){JSONObject aud=a.optJSONObject("audio");return aud==null?null:aud.optString(selectedQari,null);}
    private boolean isOnline(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities c=cm.getNetworkCapabilities(n);return c!=null&&(c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET));}catch(Exception e){return true;}}
    private float speed(){return prefs.getFloat("speed",1f);} private String speedLabel(){return String.format(Locale.US,"%.2fx",speed());} private String qariName(){for(int i=0;i<qariKeys.length;i++)if(qariKeys[i].equals(selectedQari))return qariNames[i];return qariNames[0];}private int indexQari(){for(int i=0;i<qariKeys.length;i++)if(qariKeys[i].equals(selectedQari))return i;return 0;}
    private int ayahNo(JSONObject a){JSONObject n=a.optJSONObject("number");return n==null?0:n.optInt("inSurah",0);}private int intVal(JSONObject o,String k,int d){return o==null?d:o.optInt(k,d);}private String hkey(JSONObject a){return "h_"+a.optJSONObject("number").optInt("inQuran",0);}private String fkey(JSONObject a){return "f_"+a.optJSONObject("number").optInt("inQuran",0);}private boolean isFavorite(JSONObject a){return prefs.getBoolean(fkey(a),false);}private void toggleFavorite(JSONObject a){boolean v=!isFavorite(a);prefs.edit().putBoolean(fkey(a),v).apply();toast(v?"Ayat ditambahkan ke favorit":"Ayat dihapus dari favorit");}
    private void addBottom(String label,String target){Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setMinHeight(dp(46));b.setPadding(dp(2),dp(2),dp(2),dp(2));b.setContentDescription("Buka menu "+label);bottomBar.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));b.setOnClickListener(v->{switch(target){case"home":showHome();break;case"surahs":showSurahs("");break;case"juz":showJuz();break;case"hafalan":showHafalan();break;case"settings":showSettings();break;}});}
    private void addButton(String label,Runnable action){Button b=makeButton(label);body.addView(b,matchWrap());b.setOnClickListener(v->action.run());}
    private void addButtonTo(LinearLayout parent,String label,Runnable action){Button b=makeButton(label);parent.addView(b,matchWrap());b.setOnClickListener(v->action.run());}
    private Button makeButton(String label){Button b=new Button(this);b.setText(label);b.setTextSize(15);b.setAllCaps(false);b.setTextColor(GREEN);b.setBackground(round(WHITE,12,Color.rgb(212,226,217)));b.setPadding(dp(12),dp(10),dp(12),dp(10));b.setMinHeight(dp(48));b.setContentDescription(label);LinearLayout.LayoutParams p=matchWrap();p.bottomMargin=dp(8);b.setLayoutParams(p);return b;}
    private void smallButton(LinearLayout parent,String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setAllCaps(false);b.setMinHeight(dp(44));b.setContentDescription(label);parent.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));b.setOnClickListener(v->r.run());}
    private void addListItem(LinearLayout parent,String heading,String detail,Runnable action){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(13),dp(14),dp(13));box.setBackground(round(WHITE,12,Color.rgb(225,233,228)));LinearLayout.LayoutParams p=matchWrap();p.bottomMargin=dp(8);parent.addView(box,p);TextView h=new TextView(this);h.setText(heading);h.setTextSize(16);h.setTypeface(null,Typeface.BOLD);h.setTextColor(TEXT);box.addView(h);TextView d=new TextView(this);d.setText(detail);d.setTextSize(13);d.setTextColor(MUTED);box.addView(d);box.setFocusable(true);box.setClickable(true);box.setContentDescription(heading+". "+detail);box.setOnClickListener(v->action.run());}
    private void addCardTitle(String t){TextView v=new TextView(this);v.setText(t);v.setTextSize(20);v.setTypeface(null,Typeface.BOLD);v.setTextColor(TEXT);LinearLayout.LayoutParams p=matchWrap();p.bottomMargin=dp(8);body.addView(v,p);}
    private void addText(String t,int size,int color){addTextTo(body,t,size,color);}private void addText(String t,float size,int color){addTextTo(body,t,Math.round(size),color);}private void addText(String t,float size,int color,boolean arabic){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.RIGHT);v.setTextDirection(View.TEXT_DIRECTION_RTL);v.setContentDescription("Bismillah: "+t);LinearLayout.LayoutParams p=matchWrap();p.topMargin=dp(8);p.bottomMargin=dp(8);body.addView(v,p);}private void addTextTo(LinearLayout parent,String t,int size,int color){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(color);v.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams p=matchWrap();p.bottomMargin=dp(8);parent.addView(v,p);}
    private void addSwitch(String label,boolean initial,CompoundButton.OnCheckedChangeListener listener){Switch s=new Switch(this);s.setText(label);s.setTextSize(15);s.setPadding(0,dp(8),0,dp(8));s.setChecked(initial);s.setContentDescription(label);body.addView(s,matchWrap());s.setOnCheckedChangeListener(listener);}
    private void addSpace(int dp){View v=new View(this);body.addView(v,new LinearLayout.LayoutParams(1,dp(dp)));}private LinearLayout.LayoutParams matchWrap(){return new LinearLayout.LayoutParams(-1,-2);}private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}private GradientDrawable round(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}private void showError(String s){new AlertDialog.Builder(this).setTitle("Terjadi kendala").setMessage(s).setPositiveButton("Tutup",null).show();}
    @Override public void onBackPressed(){if(!"home".equals(screen)){showHome();return;}new AlertDialog.Builder(this).setTitle("Keluar dari aplikasi?").setMessage("Apakah Anda ingin menutup Al-Qur'an Digital?").setNegativeButton("Batal",null).setPositiveButton("Keluar",(d,w)->{if(player!=null){player.release();player=null;}finish();}).show();}
    @Override protected void onPause(){super.onPause(); /* Pemutaran dipertahankan saat layar mati atau aplikasi berada di latar belakang. */}
    @Override protected void onDestroy(){if(player!=null&&!player.isPlaying()){player.release();player=null;}super.onDestroy();}
}
