# Daftar pemeriksaan sebelum rilis

- [ ] GitHub Actions berhasil menjalankan assembleDebug dan assembleRelease.
- [ ] Instal APK pada perangkat Android fisik.
- [ ] Periksa daftar 114 surah dan 6.236 ayat.
- [ ] Periksa Bismillah pada awal surah, Al-Fatihah, At-Taubah, dan An-Naml ayat 30.
- [ ] Periksa teks Arab dan terjemahan pada surah acak dari awal, tengah, dan akhir mushaf.
- [ ] Periksa batas juz 1 sampai 30, termasuk batas yang berada di tengah surah.
- [ ] Uji keenam qari dan URL audio yang tersedia.
- [ ] Uji kecepatan 1,0x, 1,25x, dan 1,5x.
- [ ] Uji pengulangan aktif tiga kali, nonaktif, jumlah lain, dan tanpa batas.
- [ ] Uji pengulangan rentang ayat.
- [ ] Uji pemutaran saat koneksi terputus atau URL audio gagal.
- [ ] Tutup dan buka aplikasi, lalu pastikan favorit, status hafalan, pengaturan, dan bacaan terakhir tersimpan.
- [ ] Uji TalkBack/Jieshuo untuk tombol, sakelar, teks Arab, dialog, dan navigasi.
- [ ] Uji tombol Kembali Android pada semua layar.
- [ ] Pastikan lisensi/atribusi data dan audio sesuai sebelum publikasi.

- [ ] Putar surah penuh, matikan layar selama beberapa menit, lalu pastikan audio tetap berjalan.
- [ ] Tekan Home atau pindah ke aplikasi lain, pastikan audio tetap berjalan.
- [ ] Pastikan notifikasi pemutaran muncul dan layanan berhenti setelah pemutaran berakhir atau tombol Berhenti ditekan.
- [ ] Aktifkan "Lanjut otomatis ke surah berikutnya", putar surah penuh, lalu pastikan setelah surah selesai berpindah ke surah berikutnya.
- [ ] Matikan "Lanjut otomatis ke surah berikutnya" dan pastikan pemutaran berhenti setelah surah selesai.
- [ ] Uji At-Taubah ayat 1 dan pastikan ayat pertama bersuara meskipun tanpa Basmalah pembuka.
