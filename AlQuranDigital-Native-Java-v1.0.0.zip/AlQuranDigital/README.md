# Al-Qur'an Digital

Aplikasi Android native Java untuk membaca Al-Qur'an, mendengarkan murottal, dan membantu latihan hafalan. Package: `com.fr.media.alqurandigital`.

## Fitur yang diimplementasikan pada source awal
- Data teks 114 surah dan 6.236 ayat disimpan di aset lokal, termasuk terjemahan Indonesia, metadata juz, dan tafsir Kemenag yang ada pada sumber.
- Daftar surah dengan pencarian nama, nomor, dan terjemahan nama.
- Membaca ayat, surah, dan juz.
- Audio per ayat menggunakan URL audio yang disediakan data sumber.
- Pilihan enam qari yang tersedia pada data.
- Kecepatan audio 1,0x, 1,25x, dan 1,5x.
- Pengulangan ayat dengan pengaturan awal aktif, tiga kali, dan pilihan tanpa batas.
- Pilih rentang ayat untuk latihan.
- Favorit, status hafalan, posisi bacaan terakhir, dan preferensi tersimpan lokal.
- Pencarian terjemahan, ukuran teks, tafsir, kontrol audio, dan navigasi native.
- Antarmuka Android native Java, bukan WebView.

## Build melalui GitHub Actions
1. Unggah isi folder proyek ini ke repositori GitHub.
2. Buka tab Actions.
3. Pilih `Build Al-Quran Digital APK`.
4. Tekan `Run workflow` atau push ke branch `main`.
5. Unduh artifact `AlQuranDigital-debug-apk` untuk pengujian.

Workflow membutuhkan JDK 17 dan Android SDK 35. APK hasil build Actions adalah APK debug untuk pengujian, bukan rilis yang sudah ditandatangani untuk distribusi publik.

## Data dan lisensi
Data bersumber dari proyek Quran API Indonesia yang dilampirkan bersama tugas. Lihat `NOTICE-QURAN-DATA-LICENSE.txt` dan `NOTICE-QURAN-API-README.md` untuk atribusi dan lisensi sumber. Periksa juga ketentuan lisensi dan atribusi dari penyedia audio sebelum mendistribusikan aplikasi.

## Batasan yang perlu diuji
- Audio membutuhkan koneksi internet. Teks lokal tetap dapat dibaca tanpa koneksi.
- Proyek ini belum diuji di perangkat Android fisik dalam lingkungan pembuatan ZIP.
- Periksa perilaku pengulangan audio pada perangkat nyata, terutama transisi otomatis antar-ayat dan ketika audio berakhir.
- Belum ada fitur unduh audio untuk pemakaian offline.
- Belum ada ekspor/impor cadangan data pengguna.
- Sebelum rilis publik, lakukan uji aksesibilitas TalkBack dan validasi teks mushaf terhadap rujukan tepercaya.
