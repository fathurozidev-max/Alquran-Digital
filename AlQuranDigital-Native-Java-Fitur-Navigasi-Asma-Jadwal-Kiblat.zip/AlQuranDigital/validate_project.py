#!/usr/bin/env python3
"""Static validation for the bundled Quran data and known listener regression."""
import json
from pathlib import Path

data_path = Path("app/src/main/assets/quran.json")
source_path = Path("app/src/main/java/com/fr/media/alqurandigital/MainActivity.java")
data = json.loads(data_path.read_text(encoding="utf-8"))
source = source_path.read_text(encoding="utf-8")
assert len(data) == 114, f"Expected 114 surahs, got {len(data)}"
assert sum(len(s["ayahs"]) for s in data) == 6236
assert data[0]["number"] == 1 and data[8]["number"] == 9 and data[26]["number"] == 27
assert data[0]["ayahs"][0]["arab"].startswith("بِسْمِ")
assert not data[8]["ayahs"][0]["arab"].startswith("بِسْمِ")
assert "بِسْمِ" in data[26]["ayahs"][29]["arab"]
assert '(button, checked)->{repeatEnabled=checked;' in source
assert '(button, checked)->{repeatForever=checked;' in source
assert 'createBismillahEntry(int surahNumber)' in source
assert 'if(surahNumber==1||surahNumber==9)return null;' in source
assert 'more.add(MediaItem.fromUri(resolveAudioUrl(bismillah)))' in source
assert 'isBismillahAudio(queue.get(lastIndex[0]))' in source
print("Static validation passed: Quran dataset, switch listeners, and Bismillah audio queue.")
